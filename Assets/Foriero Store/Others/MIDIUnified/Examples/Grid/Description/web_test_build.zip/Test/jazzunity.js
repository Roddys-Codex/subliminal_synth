var Jazz = document.getElementById("Jazz1"); 
if(!Jazz || !Jazz.isJazz) Jazz = document.getElementById("Jazz2");

function MidiIn_PortCount(){
	try{
		return Jazz.MidiInList().length;
	} catch(err) {
		alert("MidiIn_PortCount Error");
	}
}

function MidiIn_PortOpen(index){
	try{
		Jazz.MidiInOpen(index, midiProc);
	} catch(err) {
		alert("MidiIn_PortOpen Error");
	}	
}

function midiProc(t,a,b,c){
    //if(Jazz.isJazz) Jazz.MidiOut(a,b,c);
    var msg = document.getElementById("msg");
	msg.innerHTML=msg.innerHTML+"IN:"+a+" " +b+" "+c+"<br>";
	msg.scrollTop=msg.scrollHeight;
	u.getUnity().SendMessage("MIDIUnified", "MidiInMessage", a + ";" + b + ";" + c);
}

function MidiIn_PortClose(){
	try{
	Jazz.MidiInClose();
	} catch(err) {}
}

function MidiIn_PortName(index){
	try{
		var list = Jazz.MidiInList();
		return list[index];
	}catch(err){
		alert("MidiIn_PortName Error");
	}	
}

function MidiOut_PortCount(){
	try{
	return Jazz.MidiOutList().length;
	} catch(err) {
	   alert("MidiOut_PortCount Error");
	}	
}

function MidiOut_PortOpen(index){
	try{
		Jazz.MidiOutOpen(index);
	} catch(err) {
		alert("MidiOut_PortOpen Error");
	}	
}

function MidiOut_PortClose(){
	try{
		Jazz.MidiOutClose();
	} catch(err){}
}

function MidiOut_PortName(index){
	 try{
	 	var list = Jazz.MidiOutList();
	 	return list[index];
	 } catch(err) {
		alert("MidiOut_PortName Error");
	}	
}



function SendMidiMessage(Command, Data1, Data2){
	if(Jazz.isJazz) Jazz.MidiOut(Command, Data1, Data2);
	try{
	var msg = document.getElementById("msg");
	msg.innerHTML=msg.innerHTML+"OUT:"+Command+" " +Data1+" "+Data2+"<br>";
	msg.scrollTop=msg.scrollHeight;
	} catch(err) {alert(err);}
}

function MidiInList(){
	var list=Jazz.MidiInList();
	var str=""
	for(i in list) str+=list[i]+";";
	MidiIn_PortOpen(0);
	u.getUnity().SendMessage("MIDIUnified", "MidiInList", str);
}

function MidiOutList(){
	var list=Jazz.MidiOutList();
	var str=""
	for(i in list) str+=list[i]+";";
	u.getUnity().SendMessage("MIDIUnified", "MidiOutList", str);
}
